# Optivra Website - Setup Instructions

## Overview
This document provides complete setup instructions for the Optivra website, including email integration for quote requests and callback forms.

## Features Implemented

### 1. **Enhanced Design**
- ✅ Polished existing template with subtle improvements
- ✅ Smooth animations and transitions
- ✅ Responsive design for all devices
- ✅ Fun emoji avatars for team members
- ✅ Consistent footer across all pages
- ✅ SEO-optimized meta tags and structured data

### 2. **Email Integration**
- ✅ Quote request form
- ✅ Callback request form
- ✅ Google Apps Script backend
- ✅ Automatic email notifications
- ✅ Client confirmation emails
- ✅ Data storage in Google Sheets

### 3. **Performance Optimizations**
- ✅ Font loading optimization
- ✅ Image optimization hints
- ✅ Smooth scroll behavior
- ✅ Reduced motion support for accessibility

## Email Integration Setup

### Step 1: Create Google Sheet

1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "Optivra Form Submissions"
4. The script will automatically create headers when first run

### Step 2: Set Up Google Apps Script

1. In your Google Sheet, go to **Extensions > Apps Script**
2. Delete any existing code in the editor
3. Copy the entire content from `google-apps-script.js` file
4. Paste it into the Apps Script editor
5. **Important**: Update the email address in line 11:
   ```javascript
   recipientEmail: 'hello@optivra.com', // Change this to your email
   ```

### Step 3: Deploy as Web App

1. Click **Deploy > New deployment**
2. Click the gear icon ⚙️ next to "Select type"
3. Choose **Web app**
4. Configure settings:
   - **Description**: Optivra Form Handler
   - **Execute as**: Me (your email)
   - **Who has access**: Anyone
5. Click **Deploy**
6. **Authorize** the script (you may see a warning - click "Advanced" then "Go to [Project Name]")
7. **Copy the Web App URL** - it will look like:
   ```
   https://script.google.com/macros/s/AKfycby.../exec
   ```

### Step 4: Update Website Configuration

1. Open `assets/js/custom.js`
2. Find line 11:
   ```javascript
   const FORM_ENDPOINT = 'YOUR_GOOGLE_APPS_SCRIPT_URL_HERE';
   ```
3. Replace with your Web App URL:
   ```javascript
   const FORM_ENDPOINT = 'https://script.google.com/macros/s/AKfycby.../exec';
   ```
4. Save the file

### Step 5: Test the Forms

1. Open your website
2. Navigate to the Contact section
3. Fill out either the Quote Request or Callback Request form
4. Submit the form
5. Check:
   - ✅ Success message appears on the website
   - ✅ Email received at your configured address
   - ✅ Data appears in Google Sheet
   - ✅ Client receives confirmation email

## File Structure

```
optivra-main/
├── index.html                          # Main homepage
├── privacy-policy.html                 # Privacy policy page
├── terms&conditions.html               # Terms & conditions page
├── service-details.html                # Services detail page
├── google-apps-script.js               # Backend script for forms
├── SETUP-INSTRUCTIONS.md               # This file
├── assets/
│   ├── css/
│   │   ├── main.css                    # Original template CSS
│   │   └── enhancements.css            # Custom enhancements
│   ├── js/
│   │   ├── main.js                     # Original template JS
│   │   └── custom.js                   # Custom form handling
│   └── img/
│       ├── team/                       # Team images (not used - using emojis)
│       └── ...                         # Other images
```

## Customization Guide

### Changing Team Member Emojis

Edit `index.html` around line 612-675:

```html
<div class="avatar-emoji">🎯</div>  <!-- Change emoji here -->
```

Suggested emojis:
- 🎯 Strategy/Director
- 🚀 Technology/CTO
- 💡 Innovation/CEO
- 📈 Growth/Sales
- 💻 Developer
- 🎨 Designer
- 🔧 Engineer

### Updating Colors

Edit `assets/css/enhancements.css`:

```css
/* Main accent color */
--accent-color: #ffc451;

/* Gradient colors */
background: linear-gradient(135deg, #ffc451 0%, #ff9a51 100%);
```

### Modifying Form Fields

Edit `index.html` in the Contact section (lines 690-800):
- Add/remove form fields
- Change dropdown options
- Modify validation rules

## SEO Optimization

### Current SEO Features

1. **Meta Tags**
   - Title, description, keywords
   - Open Graph tags for social sharing
   - Twitter Card tags
   - Canonical URL

2. **Structured Data**
   - Organization schema
   - Contact information
   - Address details

3. **Accessibility**
   - Proper heading hierarchy
   - Alt text for images
   - ARIA labels
   - Focus states
   - Skip to content link

### Improving SEO

1. **Update Meta Tags** in `index.html`:
   ```html
   <meta name="description" content="Your custom description">
   <meta name="keywords" content="your, custom, keywords">
   ```

2. **Add More Structured Data**:
   - Service schema
   - Review schema
   - FAQ schema

3. **Create Sitemap**:
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
     <url>
       <loc>https://optivra.com/</loc>
       <priority>1.0</priority>
     </url>
     <!-- Add more URLs -->
   </urlset>
   ```

4. **Create robots.txt**:
   ```
   User-agent: *
   Allow: /
   Sitemap: https://optivra.com/sitemap.xml
   ```

## Performance Tips

1. **Optimize Images**:
   - Use WebP format
   - Compress images
   - Use appropriate sizes
   - Implement lazy loading

2. **Minify CSS/JS**:
   ```bash
   # Using npm
   npm install -g clean-css-cli uglify-js
   cleancss -o assets/css/main.min.css assets/css/main.css
   uglifyjs assets/js/main.js -o assets/js/main.min.js
   ```

3. **Enable Caching**:
   Add to `.htaccess`:
   ```apache
   <IfModule mod_expires.c>
     ExpiresActive On
     ExpiresByType image/jpg "access plus 1 year"
     ExpiresByType image/jpeg "access plus 1 year"
     ExpiresByType image/gif "access plus 1 year"
     ExpiresByType image/png "access plus 1 year"
     ExpiresByType text/css "access plus 1 month"
     ExpiresByType application/javascript "access plus 1 month"
   </IfModule>
   ```

## Troubleshooting

### Forms Not Working

1. **Check Console**: Open browser DevTools (F12) and check for errors
2. **Verify URL**: Ensure `FORM_ENDPOINT` in `custom.js` is correct
3. **Test Script**: Run test functions in Apps Script editor
4. **Check Permissions**: Ensure script has proper authorization

### Emails Not Received

1. **Check Spam Folder**
2. **Verify Email Address**: Check `recipientEmail` in Apps Script
3. **Test Email Sending**: Run `testQuoteRequest()` in Apps Script
4. **Check Quotas**: Google has daily email sending limits

### Styling Issues

1. **Clear Cache**: Hard refresh (Ctrl+Shift+R or Cmd+Shift+R)
2. **Check CSS Load Order**: Ensure `enhancements.css` loads after `main.css`
3. **Inspect Elements**: Use browser DevTools to debug styles

## Support

For issues or questions:
- Email: hello@optivra.com
- Phone: +91 74390-71619

## License

© 2024 Optivra. All Rights Reserved.